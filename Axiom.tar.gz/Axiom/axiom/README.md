AxiomChess is basically a Chess game program written in C language.
Which has the functionalities of single and player and multiplayer Chess game using on the terminal but can be also linked with the well-known available GUI's for Chess such as XBoard.


